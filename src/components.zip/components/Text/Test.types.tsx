interface TextProps {
  color?: string;
  children: React.ReactNode;
}

export default TextProps;
