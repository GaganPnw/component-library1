import React from 'react';
import styled from 'styled-components';

// Styled component for the Text
const StyledText = styled.p`
  font-size: 16px;
  color: ${(props) => props.color};
`;

// Text component
interface TextProps {
  color?: string;
  children: React.ReactNode;
}

const Text: React.FC<TextProps> = ({ color = '#000000', children }) => {
  return <StyledText color={color}>{children}</StyledText>;
};

export default Text;
