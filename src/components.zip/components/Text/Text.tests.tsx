import React from 'react';
import { render } from '@testing-library/react';
import Text from './Text';

test('renders Text component', () => {
  render(<Text>This is some text</Text>);
  // Add your assertion here
});

test('renders Text component with custom color', () => {
  render(<Text color="#ff0000">This is some text with custom color</Text>);
  // Add your assertion here
});
