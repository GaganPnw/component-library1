export { default } from './Text';
