export { default } from './HeroImage';
