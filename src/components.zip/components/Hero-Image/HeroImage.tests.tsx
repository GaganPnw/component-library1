import React from 'react';
import { render } from '@testing-library/react';
import HeroImage from './HeroImage';

test('renders HeroImage component', () => {
  render(<HeroImage src="hero-image.jpg" alt="Hero Image" />);
  // Add your assertion here
});

test('checks visibility of HeroImage component', () => {
  const { getByAltText } = render(<HeroImage src="hero-image.jpg" alt="Hero Image" />);
  const imageElement = getByAltText('Hero Image');
  expect(imageElement).toBeVisible();
});
