interface HeroImageProps {
  src: string;
  alt: string;
}

export default HeroImageProps;
