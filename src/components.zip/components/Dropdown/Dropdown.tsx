import React, { useState } from 'react';
import styled from 'styled-components';

const Container = styled.div`
  position: relative;
`;

const Select = styled.select<{ disabled: boolean }>`
  width: 200px;
  padding: 8px;
  background-color: ${({ disabled }) => (disabled ? '#dddddd' : '#ffffff')};
  color: ${({ disabled }) => (disabled ? '#888888' : '#000000')};
  cursor: ${({ disabled }) => (disabled ? 'not-allowed' : 'pointer')};
`;

interface DropdownProps {
  options: string[];
  disabled: boolean;
}

const Dropdown: React.FC<DropdownProps> = ({ options, disabled }) => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedOption(event.target.value);
  };

  return (
    <Container>
      <Select value={selectedOption} disabled={disabled} onChange={handleChange}>
        <option value="">Select an option</option>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </Select>
    </Container>
  );
};

export default Dropdown;
