interface DropdownProps {
  options: string[];
  disabled: boolean;
}

export default DropdownProps;
