import React from 'react';
import { render, screen } from '@testing-library/react';
import Card from './Card';

test('renders Card component', () => {
  render(<Card title="Title" description="Description" disabled={false} />);
  const cardElement = screen.getByRole('article');
  expect(cardElement).toBeVisible();
});

test('checks background color change when disabled', () => {
  render(<Card title="Title" description="Description" disabled={true} />);
  const cardElement = screen.getByRole('article');
  expect(cardElement).toHaveStyle('background-color: #dddddd');
});
