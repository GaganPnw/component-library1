export { default } from './Label';
export * from './Label.types';
