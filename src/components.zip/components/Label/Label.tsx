import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components';

const StyledLabel = styled.label`
  display: block;
  font-weight: bold;
  margin-bottom: 8px;
`;

interface LabelProps {
  text: string;
}

const Label: React.FC<LabelProps> = ({ text }) => {
  return <StyledLabel>{text}</StyledLabel>;
};

Label.propTypes = {
  text: PropTypes.string.isRequired,
};

export default Label;
