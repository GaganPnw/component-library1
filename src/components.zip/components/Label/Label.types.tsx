export interface LabelProps {
  text: string;
}
