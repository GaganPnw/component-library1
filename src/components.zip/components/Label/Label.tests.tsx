import React from 'react';
import { render } from '@testing-library/react';
import Label from './Label';

test('renders label with text', () => {
  const { getByText } = render(<Label text="Test Label" />);
  const labelElement = getByText(/Test Label/i);
  expect(labelElement).toBeInTheDocument();
});

test('renders label with custom text', () => {
  const { getByText } = render(<Label text="Custom Label" />);
  const labelElement = getByText(/Custom Label/i);
  expect(labelElement).toBeInTheDocument();
});
