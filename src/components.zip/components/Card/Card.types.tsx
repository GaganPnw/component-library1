interface CardProps {
  title: string;
  description: string;
  disabled?: boolean;
}

export default CardProps;
