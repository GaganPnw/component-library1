import React from 'react';
import { render, fireEvent } from '@testing-library/react';
import Card from './Card';

test('renders Card component', () => {
  const { getByTestId } = render(
    <Card title="Test Title" description="Test Description" />
  );
  const cardElement = getByTestId('card');
  expect(cardElement).toBeVisible();
});

test('renders Card component with custom background color when disabled', () => {
  const { container } = render(
    <Card title="Test Title" description="Test Description" disabled />
  );
  const cardElement = container.firstChild as HTMLElement;
  expect(cardElement).toHaveStyle('background-color: #CCCCCC');
});

test('changes background color on click when enabled', () => {
  const { container } = render(
    <Card title="Test Title" description="Test Description" />
  );
  const cardElement = container.firstChild as HTMLElement;

  fireEvent.click(cardElement);
  expect(cardElement.style.backgroundColor).toBe('rgb(0, 255, 0)');

  fireEvent.click(cardElement);
  expect(cardElement.style.backgroundColor).toBe('rgb(255, 255, 255)');
});
