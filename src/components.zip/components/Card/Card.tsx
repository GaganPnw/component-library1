import React from 'react';
import styled from 'styled-components';

const Container = styled.div<{ disabled: boolean }>`
  background-color: ${({ disabled }) => (disabled ? '#dddddd' : '#ffffff')};
  border-radius: 4px;
  padding: 16px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  cursor: ${({ disabled }) => (disabled ? 'not-allowed' : 'pointer')};
`;

const Title = styled.h2`
  font-size: 18px;
  margin-bottom: 8px;
`;

const Description = styled.p`
  font-size: 14px;
  color: #555555;
`;

interface CardProps {
  title: string;
  description: string;
  disabled: boolean;
}

const Card: React.FC<CardProps> = ({ title, description, disabled }) => {
  return (
    <Container disabled={disabled}>
      <Title>{title}</Title>
      <Description>{description}</Description>
    </Container>
  );
};

export default Card;
