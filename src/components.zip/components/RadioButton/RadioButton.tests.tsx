import React from 'react';
import { render } from '@testing-library/react';
import RadioButton from './RadioButton';

test('renders RadioButton component', () => {
  render(
    <RadioButton
      id="radio1"
      label="Option 1"
      checked={false}
      onChange={(checked) => {
        console.log('Checked:', checked);
      }}
    />
  );
  // Add your assertion here
});

test('calls onChange function when radio button is selected', () => {
  // Implement the test logic to check if the onChange function is called correctly
});
