import React from 'react';
import styled from 'styled-components';

// Styled components for the RadioButton
const Container = styled.div`
  display: flex;
  align-items: center;
`;

const Input = styled.input`
  margin-right: 8px;
`;

const Label = styled.label``;

// RadioButton component
interface RadioButtonProps {
  id: string;
  label: string;
  checked: boolean;
  onChange: (checked: boolean) => void;
}

const RadioButton: React.FC<RadioButtonProps> = ({ id, label, checked, onChange }) => {
  const handleRadioChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onChange(event.target.checked);
  };

  return (
    <Container>
      <Input type="radio" id={id} checked={checked} onChange={handleRadioChange} />
      <Label htmlFor={id}>{label}</Label>
    </Container>
  );
};

export default RadioButton;
