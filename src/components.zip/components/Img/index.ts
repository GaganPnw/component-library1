export { default } from './Img';
