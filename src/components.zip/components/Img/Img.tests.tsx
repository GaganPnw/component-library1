import React from 'react';
import { render } from '@testing-library/react';
import Img from './Img';

test('renders Img component', () => {
  render(<Img src="https://example.com/image.jpg" alt="Example Image" />);
  // Add your assertion here
});

test('changes background color in disabled state', () => {
  // Implement the test logic to check the background color change
});
