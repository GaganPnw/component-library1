interface ImgProps {
  src: string;
  alt: string;
}

export default ImgProps;
