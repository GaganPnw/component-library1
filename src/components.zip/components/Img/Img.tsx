import React from 'react';
import styled from 'styled-components';

// Styled component for the Img
const Image = styled.img`
  max-width: 100%;
  height: auto;
`;

// Img component
interface ImgProps {
  src: string;
  alt: string;
}

const Img: React.FC<ImgProps> = ({ src, alt }) => {
  return <Image src={src} alt={alt} />;
};

export default Img;
